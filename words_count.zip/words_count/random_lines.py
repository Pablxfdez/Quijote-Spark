# -*- coding: utf-8 -*-
"""
PABLO fERNÁNDEZ DEL AMO
"""

import random
import sys


def main(infilename, outfilename, ratio):
    # Abrimos el archivo de entrada en modo lectura
    with open(infilename) as infile:
        # Abrimos el archivo de salida en modo escritura
        with open(outfilename, 'w') as outfile:
            # Iteramos sobre cada línea del archivo de entrada
            for line in infile:
                # Si el número aleatorio generado es menor o igual a la relación de muestreo, escribimos la línea en el archivo de salida
                if random.random() <= ratio:
                    outfile.write(line)

if __name__ == "__main__":
    # Verificamos si se pasaron los nombres de archivo de entrada, salida y la relación de muestreo como argumentos de línea de comandos
    if len(sys.argv) < 4:
       print(f"Usage: {sys.argv[0]} <infilename> <outfilename> <ratio")
       exit(1)
    # Obtenemos los nombres de archivo de entrada, salida y la relación de muestreo de los argumentos de línea de comandos
    infilename = sys.argv[1]
    outfilename = sys.argv[2]
    ratio = float(sys.argv[3])
    # Ejecutamos la función principal del programa
    main(infilename, outfilename, ratio)
