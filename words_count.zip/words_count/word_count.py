# -*- coding: utf-8 -*-
'''
PABLO FERNÁNDEZ DEL AMO
'''

from pyspark import SparkContext
import sys

def main(infilename, outfilename):
    with SparkContext() as sc:
        # Establecemos el nivel de registro de errores en "ERROR"
        sc.setLogLevel("ERROR")
        # Cargamos el archivo de texto en un RDD
        data = sc.textFile(infilename)
        # Mapeamos cada línea del RDD a la longitud de las palabras en ella y creamos un nuevo RDD
        words_rdd = data.map(lambda x: len(x.split()))
        # Recopilamos la lista de longitudes de palabras y la convertimos en una cadena
        words_list_collect = str(words_rdd.collect())
        # Calculamos la suma de todas las longitudes de palabras del RDD y la convertimos en una cadena
        total_palabras = str(words_rdd.sum())
        # Abrimos el archivo de salida en modo escritura
        with open(outfilename, 'w') as outfile:
            # Escribimos una línea de separación y una cabecera de resultados en el archivo de salida
            outfile.write('RESULTS------------------ \n')
            # Escribimos el número total de palabras en el archivo de salida
            outfile.write(total_palabras)
            
if __name__ == "__main__":
    # Verificamos si se pasaron los nombres de archivo de entrada y salida como argumentos de línea de comandos
    if len(sys.argv) < 3:
       print(f"Usage: {sys.argv[0]} <infilename> <outfilename>")
       exit(1)
    # Obtenemos los nombres de archivo de entrada y salida de los argumentos de línea de comandos
    infilename = sys.argv[1]
    outfilename = sys.argv[2]
    # Ejecutamos la función principal del programa
    main(infilename, outfilename)
